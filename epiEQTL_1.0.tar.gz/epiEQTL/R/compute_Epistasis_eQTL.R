compute_Epistasis_eQTL <-
function(plink2exe, plinkexe, geno_file, expression_file, covariate_file, subj_select, folder, GENE, flank, design, MAC, missingRate, LD_pruning = 0.7, scanThreshold = 1e-6, nperm=10000, method=c("Wald", "WaldSand", "WaldSand-Cond", "Wald-Cond", "Cordell"), eQTLFile=NULL)
{	## checking input
	if(!method %in% c("Wald", "WaldSand", "WaldSand-Cond", "Wald-Cond", "Cordell"))
	{	stop("Method input is unknown, please choose from 'Wald', 'WaldSand', 'WaldSand-Cond', 'Wald-Cond', and 'Cordell'.\n")
	}
	if(!class(flank) %in% c("integer", "numeric"))
	{	stop("The parameter flank should be of class integer or numeric.\n")
	}
	
	library(data.table)
	options(stringsAsFactors=FALSE)
	folder2 = paste(folder, GENE, sep="/")
	dir.create(file.path(folder2), showWarnings=FALSE)
	dir.create(file.path(folder2, "WGS"), showWarnings = FALSE)
	dir.create(file.path(folder2, "RNA"), showWarnings = FALSE)
	dir.create(file.path(folder2, "results"), showWarnings = FALSE)
	setwd(folder2)
	
	data(GRCh38_gene)
    ## convert gene ID to Ensembl ID and find position, in GRCh38
	geneOne = GRCh38_gene[GRCh38_gene$hgnc_symbol==GENE,]
	if(nrow(geneOne)==0)
	{	stop("Cannot find the gene ", GENE, "!\n")
	}	
	geneOne$Start = geneOne$gene_start - flank
	geneOne$End = geneOne$gene_end + flank
	geneOne = geneOne[geneOne$chr %in% c(1:22, "X", "Y"),]
	chr = geneOne$chr
	cmd=paste0(plink2exe," --pfile ", folder, "/" , geno_file, " --mac ", MAC, " --geno ", missingRate, " --keep ",  folder, "/" ,subj_select, " --chr ", chr, " --from-bp ", geneOne$Start, " --to-bp ", geneOne$End, " --make-bed --out ", folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE)
	system(cmd)
	if(!file.exists(paste0(folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE, ".bim")))
	{	stop("No variants remaining after main filters in the genotype file.\n")
	}
		
	### LD pruning
	cmd = paste0(plink2exe, " --bfile ", folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE, " --indep-pairwise 50 5 ", LD_pruning, " --out ", folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE)
	system(cmd)
	cmd = paste0(plink2exe, " --bfile ", folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE, " --extract ", folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE, ".prune.in --make-bed --out ", folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE, "_indep")
	system(cmd)
	
	### wald test scanning	
	counts = read.csv(paste0(folder, "/" ,expression_file)) 
	if(!any(counts$X==geneOne$gene))
	{	stop("Gene (", GENE, ") is not in the gene expression file. \n")
	}
	expressionOne= counts[counts$X==geneOne$gene,]
	exprOne = log(expressionOne[,-1])
	exprOne2 = matrix(t(exprOne), length(exprOne),1)
	colnames(exprOne2) = as.character(expressionOne$X)
	covariates = fread(paste0(folder, "/" ,covariate_file), data.table=F, header=T)
	phenoFile = data.frame(FID=(colnames(counts)[-1]), IID=(colnames(counts)[-1]), (covariates[,-c(1,2)]), exprOne2)
	lmtemp = lm(formula(paste0(expressionOne$X, "~", paste(colnames(phenoFile)[-c(1, 2, ncol(phenoFile))], collapse="+"))), data=phenoFile)
	phenoFile$res = resid(lmtemp)
	output = paste0(folder2, "/RNA/expression_pheno.txt")
	write.table(phenoFile, output, quote=F, row.names=F, col.names=T)

	### running plink on the residual
	originalFile = paste0(folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE)
	plinkFile = paste0(folder2, "/WGS/geno_chr", chr, "_nhw_pass_", GENE, "_indep")
	out2 = paste0(folder2, "/results/plinkrun_chr", chr, "_", GENE)
	cat("Running the gene-wide scan using the Wald test.\n")
	#cmd = paste0("/udd/redaq/tools/plink032819/plink --bfile ", plinkFile, " --epistasis --pheno ", output, " --pheno-name res --epi1 ", scanThreshold, " --epi2 1e-8 --allow-no-sex --out ", out2)
	 
	cmd = paste0(plinkexe, " --bfile ", plinkFile, " --epistasis --pheno ", output, " --pheno-name res --epi1 ", scanThreshold, " --epi2 1e-8 --allow-no-sex --out ", out2)
	
	system(cmd)
	## grep number of test
	cmd = paste0("grep 'valid tests performed, summary written to' ", out2, ".log") 
	returnValue = system(cmd, intern=TRUE)
	ntest = strsplit(returnValue, split=" ")[[1]][1]
	
	results = fread(paste0(out2, ".epi.qt"), header=T, data.table=F)
	if(nrow(results)==0)
	{	warning("There is no significant epistasis effects in the gene-wide scan using Wald test.\n")
		return(list(results=results, numTest=ntest))
	}
	if(method=="WaldSand-Cond" | method=="WaldSand")
	{	
		### For significant ones, run series of tests to remove false positives
		
		results = compute_WaldSand(plink2exe, plinkFile, paste0(out2, ".epi.qt"), output, design, folder2, GENE, nperm)
		write.table(results, paste0(folder2, "/results/plinkrun_chr", chr, "_", GENE, ".sandCheck.txt"), quote=F, row.names=F, col.names=T)
		if(method=="WaldSand")
		{
			return(list(results=results, numTest=ntest))
		}
		if(any(results$wald_sand_perm < 0.05/as.integer(ntest)))
		{   cat("Conditional analysis on marginal eQTLs using HC-sandwich estimator.\n")
			#### If still significant, use conditional analysis using Wald test with sandwich estimator
			## 1. find marginal eQTLs
			if(is.na(eQTLFile))
			{
				out3 = paste0(folder2, "/results/plinkrun_chr", chr, "_", GENE, "_eQTL")
				cmd = paste0(plinkexe, " --bfile ", originalFile, " --linear --pheno ", output, " --pheno-name res --allow-no-sex --out ", out3)
				system(cmd)
				eQTL = fread(paste0(out3, ".assoc.linear"), data.table=F, header=T)
				eQTL$FDR = p.adjust(eQTL$P, method="fdr")
				eQTL2 = eQTL[eQTL$FDR<0.05,]
			}else
			{	eQTL = fread(paste0(folder, "/", eQTLFile), header=T, data.table=F)
				eQTL2= eQTL[eQTL$gene==geneOne$gene&eQTL$FDR<0.05,]
				bimOriginal = fread(paste0(originalFile, ".bim"), data.table=F)
				eQTL2 = eQTL2[eQTL2$SNP %in% bimOriginal$V2,]
			}
			## 2. Conditional on all marginal eQTLs, and find the largest p-value possible
			if(nrow(eQTL2)>0)
			{
				results2 = results[!is.na(results$wald_sand_perm)&results$wald_sand_perm < 0.05/as.integer(ntest),]
				results3 = compute_WaldSand_cond(plink2exe, originalFile, results2, eQTL2, output, design, folder2, GENE, nperm)
				write.table(results3, paste0(folder2, "/results/plinkrun_chr", chr, "_", GENE, ".condSand.txt"), quote=F, row.names=F, col.names=T)
				return (list(results=results3, numTest=ntest))
			}else
			{	cat("There is no marginal eQTL for conditional analyses.\n")
				return(list(results=results, numTest=ntest))
			}
		}else
		{	return(list(results=results, numTest=ntest))
		}

	
	}else if(method=="Wald-Cond")
	{	cat("Conditional analysis on marginal eQTLs using the wald test.\n")
		results=fread(paste0(out2, ".epi.qt"),header=T, data.table=F)
		if(any(results$P < 0.05/as.integer(ntest)))
		{	
				#### If still significant, use conditional analysis using Wald test 
				## 1. find marginal eQTLs
				if(is.na(eQTLFile))
				{	
					out3 = paste0(folder2, "/results/plinkrun_chr", chr, "_", GENE, "_eQTL")
					cmd = paste0(plinkexe, " --bfile ", originalFile, " --linear --pheno ", output, " --pheno-name res --allow-no-sex --out ", out3)
					system(cmd)
					eQTL = fread(paste0(out3, ".assoc.linear"), data.table=F, header=T)
					eQTL$FDR = p.adjust(eQTL$P, method="fdr")
					eQTL2 = eQTL[eQTL$FDR<0.05,]	
				}else
				{	eQTL = fread(paste0(folder, "/", eQTLFile), header=T, data.table=F)
					eQTL2= eQTL[eQTL$gene==geneOne$gene&eQTL$FDR<0.05,]
					bimOriginal = fread(paste0(originalFile, ".bim"), data.table=F)
					eQTL2 = eQTL2[eQTL2$SNP %in% bimOriginal$V2,]
				}
				## 2. Conditional on all marginal eQTLs, and find the largest p-value possible
				if(nrow(eQTL2)>0)
				{
					results2 = results[results$P < 0.05/as.integer(ntest),]
					results3 = compute_Wald_cond(plink2exe, originalFile, results2, eQTL2, output, design, folder2, GENE)
					write.table(results3, paste0(folder2, "/results/plinkrun_chr", chr, "_", GENE, ".condWald.txt"), quote=F, row.names=F, col.names=T)
					return(list(results=results3, numTest=ntest))
				}else
				{	cat("There is no marginal eQTL for conditional analyses.\n")
					return(list(results=results, numTest=ntest))
				}
		}else
		{	warning("There is no significant SNP pairs using the Wald screening.\n")
			return(list(results=results, numTest=ntest))
		}
	}else if(method=="Cordell")
	{	results=fread(paste0(out2, ".epi.qt"),header=T, data.table=F)
		if(nrow(results)>0)
		{	cat("Running epistasis test using the Cordell's 4df test.\n")
			results = compute_cordell(plink2exe, plinkFile, paste0(out2, ".epi.qt"), output, design, folder2, GENE)
		}else
		{	cat("There is no significant test using the genome-wide scan. Cordell 4df test was not done. \n")
			
		}
		return(list(results=results, numTest=ntest))
	}else if(method=="Wald")
	{	
		return(list(results=results, numTest=ntest))
	}else
	{	
	}
}
