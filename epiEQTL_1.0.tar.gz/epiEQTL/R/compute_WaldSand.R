compute_WaldSand <-
function(plink2exe, plinkFile, plinkResult, pheno_file, design, folder, GENE, nperm=10000)
{	library(sandwich)
	options(stringsAsFactors=FALSE)

	### extract the significant variants in plink file
	sigResults = fread(plinkResult,header=T, data.table=F)
	varSet = unique(c(sigResults$SNP1, sigResults$SNP2))
	varSetOutput = paste0(folder, "/results/plinkrun_", GENE, "_sigEpis")
	write.table(varSet, varSetOutput, quote=F, row.names=F, col.names=F)
	cmd = paste(plink2exe, " --bfile ", plinkFile, " --extract ", varSetOutput, " --make-bed --out ", varSetOutput)
	system(cmd)
	cmd = paste(plink2exe, " --bfile ", varSetOutput, " --recode A --out ", varSetOutput)
	system(cmd)

	### load the raw file
	raw = fread(paste0(varSetOutput, ".raw"), header=T, data.table=F)
	fam = fread(paste0(varSetOutput, ".fam"), header=F, data.table=F)
	bim = fread(paste0(varSetOutput, ".bim"), header=F, data.table=F)
	bim$index= 1:nrow(bim)
	sigResults$index1 = bim[match(sigResults$SNP1, bim$V2),]$index
	sigResults$index2 = bim[match(sigResults$SNP2, bim$V2),]$index
	subjInfo = read.table(pheno_file, header=T)
	subjInfo2 = subjInfo[match(fam$V2, subjInfo$IID),]

	### run wald test with sandwich estimator, boostrapping to remove heteroscasticity
	GENOall = data.frame(raw[,-c(1:6)])
	dataForm = data.frame(subjInfo2, GENOall)
	
	sigResults$wald = NA
	sigResults$wald_sand =NA
	sigResults$wald_sand_perm =NA
	pheno = "res"
	for(i in 1:nrow(sigResults))
	{	cat(i)
		indexes = as.integer(sigResults[i,c("index1", "index2")])
		GENO = GENOall[,indexes]
		#lmtemp1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1], "~", paste(colnames(phenoFile)[-c(1, 2, ncol(phenoFile)-1, ncol(phenoFile))], collapse="+"), "+", paste(colnames(GENOall)[indexes], collapse="*") )), data=dataForm)
		lmtemp1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1],  paste(design, paste(colnames(GENOall)[indexes], collapse="*"), sep="+"))), data=dataForm)

		### linear regression with adjustment
		### jackknife HC covariance HC3
		result = summary(lmtemp1)$coef
		ddtemp = vcovHC(lmtemp1, type="HC3")
		whichTerm = which(grepl(":", rownames(result)))
		statsReal = result[whichTerm,1]^2/ddtemp[whichTerm,whichTerm]
		pvalue4 = 1-pchisq(statsReal, df=1)
		sigResults$wald_sand[i] = pvalue4
		sigResults$wald[i] = result[whichTerm, 4]

		### permutation
		#nperm = 1000
		## null
		lmtempnull = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1], paste(design, paste(colnames(GENOall)[indexes], collapse="+"), sep="+") )), data=dataForm)

		if(grepl(":", rownames(result)[nrow(result)]))
		{	permSim1 = rep(NA, nperm)
			for(sim in 1:nperm)
			{       		if(sim%%100==0)
							{cat("sim", sim)
							}
							GENOtemp = GENO#[indexSim,]
							subjInfoTemp = cbind(matrix(rep(1, nrow(subjInfo2), 1)), subjInfo2, GENOtemp)
							colnames(subjInfoTemp)[1]="intercept"
							mutemp = as.matrix(subjInfoTemp[,c("intercept", names(lmtempnull$coef)[-1])]) %*% matrix(lmtempnull$coef, length(lmtempnull$coef), 1)
							subjInfoTemp$PHENOTYPE = rnorm(nrow(subjInfo), mutemp, sd=summary(lmtempnull)$sigma)
							lmtemp11 = lm(formula(paste0("PHENOTYPE", paste(design, paste(c(colnames(GENOall)[indexes], paste0(colnames(GENOall)[indexes], collapse="*")), collapse="+"), sep="+") )), data=subjInfoTemp)

							resulttemp = summary(lmtemp11)$coef
							### jackknife HC covariance HC3
							ddtemp = vcovHC(lmtemp11, type="HC3")
							if(all(is.na(ddtemp)))
							{	warning("The HC covariance matrix is NA!\n")
							}
							stats = (resulttemp[nrow(result),1])^2/ddtemp[nrow(resulttemp),nrow(resulttemp)]
							permSim1[sim] = stats
			}
			permPvalue1= sum(permSim1 >=abs(statsReal)|permSim1<=-abs(statsReal),na.rm=T)/sum(!is.na(permSim1))
			
			while(!is.na(permPvalue1)&permPvalue1<= 0.00000001 & permPvalue1 >= 0.0000000001)
			{		        for(sim in 1:nperm)
							{       		if(sim%%100==0)
											{cat("sim", sim)
											}
											GENOtemp = GENO#[indexSim,]
											subjInfoTemp = cbind(matrix(rep(1, nrow(subjInfo2), 1)), subjInfo2, GENOtemp)
											colnames(subjInfoTemp)[1]="intercept"
											mutemp = as.matrix(subjInfoTemp[,c("intercept", names(lmtempnull$coef)[-1])]) %*% matrix(lmtempnull$coef, length(lmtempnull$coef), 1)
											subjInfoTemp$PHENOTYPE = rnorm(nrow(subjInfo), mutemp, sd=summary(lmtempnull)$sigma)
											lmtemp11 = lm(formula(paste0("PHENOTYPE", paste(design, paste(c(colnames(GENOall)[indexes], paste0(colnames(GENOall)[indexes], collapse="*")), collapse="+"), sep="+") )), data=subjInfoTemp)

											resulttemp = summary(lmtemp11)$coef
											### jackknife HC covariance HC3
											ddtemp = vcovHC(lmtemp11, type="HC3")
											stats = (resulttemp[nrow(result),1])^2/ddtemp[nrow(resulttemp),nrow(resulttemp)]
											permSim1 = c(permSim1,stats)
							}
							permPvalue1= sum(permSim1 >=abs(statsReal)|permSim1<=-abs(statsReal),na.rm=T)/sum(!is.na(permSim1))
							cat("permPvalue1: ", permPvalue1, "\n")

			}
			sigResults$wald_sand_perm[i] = permPvalue1
		}else
		{   sigResults$wald_sand_perm[i] = NA
		}

 
	}           
	return (sigResults)

}
