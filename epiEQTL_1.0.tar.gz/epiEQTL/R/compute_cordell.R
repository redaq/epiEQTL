compute_cordell <-
function(plink2exe, plinkFile, plinkResult, pheno_file, design, folder, GENE)
{
	options(stringsAsFactors=FALSE)
	getTwoCol <- function(geno)
	{
			x = ifelse(geno==2, 1, ifelse(geno==1, 0, ifelse(geno==0, -1, NA)) ) ## additive effect
			z = ifelse(geno==2, -0.5, ifelse(geno==1, 0.5, ifelse(geno==0, -0.5, NA)) ) ### dominant effect
			return(cbind(x, z))
	}

	### extract the significant variants in plink file
	sigResults = fread(plinkResult,header=T, data.table=F)
	varSet = unique(c(sigResults$SNP1, sigResults$SNP2))
	varSetOutput = paste0(folder, "/results/plinkrun_", GENE, "_sigEpis")
	write.table(varSet, varSetOutput, quote=F, row.names=F, col.names=F)
	cmd = paste(plink2exe, " --bfile ", plinkFile, " --extract ", varSetOutput, " --make-bed --out ", varSetOutput)
	system(cmd)
	cmd = paste(plink2exe, " --bfile ", varSetOutput, " --recode A --out ", varSetOutput)
	system(cmd)

	### load the raw file
	raw = fread(paste0(varSetOutput, ".raw"), header=T, data.table=F)
	fam = fread(paste0(varSetOutput, ".fam"), header=F, data.table=F)
	bim = fread(paste0(varSetOutput, ".bim"), header=F, data.table=F)
	bim$index= 1:nrow(bim)
	sigResults$index1 = bim[match(sigResults$SNP1, bim$V2),]$index
	sigResults$index2 = bim[match(sigResults$SNP2, bim$V2),]$index
	subjInfo = read.table(pheno_file, header=T)
	subjInfo2 = subjInfo[match(fam$V2, subjInfo$IID),]

	### run wald test with sandwich estimator, boostrapping to remove heteroscasticity
	GENOall = data.frame(raw[,-c(1:6)])
	dataForm = data.frame(subjInfo2, GENOall)
	
	sigResults$cordell = NA
	pheno = "res"
	for(i in 1:nrow(sigResults))
	{	cat(i)
		indexes = as.integer(sigResults[i,c("index1", "index2")])
		GENO = GENOall[,indexes]
		temp2 = getTwoCol(GENO[,1])
		temp3 = getTwoCol(GENO[,2])
		colnames(temp2) = paste0(colnames(GENO)[1], c("_x", "_z"))
		colnames(temp3) = paste0(colnames(GENO)[2], c("_x", "_z"))
		testSNP = c(colnames(temp2),colnames(temp3))
		testSNPGENO = data.frame(cbind(temp2, temp3))
		colnames(testSNPGENO) = testSNP
		combos = combn(testSNP, 2)
		combos = combos[,-c(1,6)]
		subjInfo3 = data.table(subjInfo2, testSNPGENO)
		model1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1],  paste(design, paste(testSNP, collapse="+"), sep="+"))), data=subjInfo3)
		model2 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1], paste(design, paste(testSNP, collapse="+"), paste(apply(combos,2, paste0, collapse="*"), collapse="+"), sep="+"))), data=subjInfo3)
		real4 = anova(model1, model2)
		sigResults$cordell[i] = real4[6][2,1]
		

	
	}           
	return (sigResults)


}
