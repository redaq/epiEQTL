compute_Wald_cond <-
function(plink2exe, plinkFile, results2, eQTL, output, design,folder, GENE)
### This function runs the wald test with sandwich estimator, and with parametric bootstrapping to obtain the pvalues
{	library(sandwich)
	options(stringsAsFactors=FALSE)

	### extract the significant variants in plink file
	sigResults = results2
	varSet = unique(c(sigResults$SNP1, sigResults$SNP2, eQTL$SNP))
	varSetOutput = paste0(folder, "/results/plinkrun_", GENE, "_sigEpis_cond")
	write.table(varSet, varSetOutput, quote=F, row.names=F, col.names=F)
	cmd = paste(plink2exe, " --bfile ", plinkFile, " --extract ", varSetOutput, " --make-bed --out ", varSetOutput)
	system(cmd)
	cmd = paste(plink2exe, " --bfile ", varSetOutput, " --recode A --out ", varSetOutput)
	system(cmd)

	### load the raw file
	raw = fread(paste0(varSetOutput, ".raw"), header=T, data.table=F)
	fam = fread(paste0(varSetOutput, ".fam"), header=F, data.table=F)
	bim = fread(paste0(varSetOutput, ".bim"), header=F, data.table=F)
	bim$index= 1:nrow(bim)
	sigResults$index1 = bim[match(sigResults$SNP1, bim$V2),]$index
	sigResults$index2 = bim[match(sigResults$SNP2, bim$V2),]$index
	subjInfo = read.table(output, header=T)
	subjInfo2 = subjInfo[match(fam$V2, subjInfo$IID),]
	eQTLindex = which(bim$V2 %in% eQTL$SNP) 

	### run wald test with sandwich estimator, boostrapping to remove heteroscasticity
	GENOall = data.frame(raw[,-c(1:6)])
	colnames(GENOall) = bim$V2
	dataForm = data.frame(subjInfo2, GENOall)
	sigResults$wald_cond =NA
	sigResults$wald_cond_SNP =NA
	pheno = "res"
	for(i in 1:nrow(sigResults))
	{	cat(i)
		indexes = as.integer(sigResults[i,c("index1", "index2")])
		GENO = GENOall[,c(indexes, eQTLindex)]
		eQTLresults = data.frame(condSNP=matrix(eQTL$SNP, length(eQTL$SNP), 1), wald_cond=NA)
		for(j in 1:length(eQTL$SNP))
		{
			#lmtemp1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1], "~", paste(colnames(phenoFile)[-c(1, 2, ncol(phenoFile)-1, ncol(phenoFile))], collapse="+"), "+", paste(colnames(GENOall)[indexes], collapse="*") )), data=dataForm)
			lmtemp1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1],  paste(design, paste(colnames(GENOall)[indexes],  collapse="*"), colnames(GENOall)[eQTLindex[j]],sep="+"))), data=dataForm)
			
			### linear regression with adjustment
			### jackknife HC covariance HC3
			result = summary(lmtemp1)$coef
			if(any(grepl(":", rownames(result))))
			{
				whichTerm = which(grepl(":", rownames(result)))
				eQTLresults$wald_cond[j] = result[whichTerm, 4]
			
			}else
			{   
				eQTLresults$wald_cond[j] = NA
			}
		}
		sigResults$wald_cond[i] = max(eQTLresults$wald_cond)
		sigResults$wald_cond_SNP[i] = eQTLresults$condSNP[which(eQTLresults$wald_cond==max(eQTLresults$wald_cond))]
	}           
	return (sigResults)

}
