#### Compute using WaldSand tests with boostrapped p-values
#### Could be conditional or unconditional tests
compute_Epistasis_2SNPs <- function(plink2exe, plinkFile, results2, SNP1, SNP2, output, design, folder, condSNP=NULL, nperm=10000)
{	if(is.na(condSNP))
	{ ### just SNP pair
	
	}else
	{ ### conditional analyses
	}
}

compute_WaldSand_cond <-
function(plink2exe, plinkFile, results2, eQTL, output, design,  MAC, missingRate, folder, GENE, nperm)
### This function runs the wald test with sandwich estimator, and with parametric bootstrapping to obtain the pvalues
{	
	options(stringsAsFactors=FALSE)

	### extract the significant variants in plink file
	sigResults = results2
	varSet = unique(c(sigResults$SNP1, sigResults$SNP2, eQTL$SNP))
	varSetOutput = paste0(folder, "/results/plinkrun_", GENE, "_sigEpis_cond")
	write.table(varSet, varSetOutput, quote=F, row.names=F, col.names=F)
	cmd = paste(plink2exe, " --bfile ", plinkFile, " --extract ", varSetOutput, " --make-bed --out ", varSetOutput)
	system(cmd)
	cmd = paste(plink2exe, " --bfile ", varSetOutput, " --recode A --out ", varSetOutput)
	system(cmd)

	### load the raw file
	raw = fread(paste0(varSetOutput, ".raw"), header=T, data.table=F)
	fam = fread(paste0(varSetOutput, ".fam"), header=F, data.table=F)
	bim = fread(paste0(varSetOutput, ".bim"), header=F, data.table=F)
	bim$index= 1:nrow(bim)
	sigResults$index1 = bim[match(sigResults$SNP1, bim$V2),]$index
	sigResults$index2 = bim[match(sigResults$SNP2, bim$V2),]$index
	subjInfo = read.table(output, header=T)
	subjInfo2 = subjInfo[match(fam$V2, subjInfo$IID),]
	eQTLindex = which(bim$V2 %in% eQTL$SNP) 

	### run wald test with sandwich estimator, boostrapping to remove heteroscasticity
	GENOall = data.frame(raw[,-c(1:6)])
	colnames(GENOall) = bim$V2
	GENOall = data.frame(GENOall)
	dataForm = data.frame(subjInfo2, GENOall)
	sigResults$wald_cond =NA
	sigResults$wald_sand_cond =NA
	sigResults$wald_sand_cond_perm =NA
	pheno = "res"
	for(i in 1:nrow(sigResults))
	{	cat(i)
		indexes = as.integer(sigResults[i,c("index1", "index2")])
		GENO = GENOall[,c(indexes, eQTLindex)]
		eQTLresults = data.frame(condSNP=matrix(eQTL$SNP, length(eQTL$SNP), 1), wald_cond=NA, wald_sand_cond=NA, wald_sand_cond_perm=NA)
		for(j in 1:length(eQTL$SNP))
		{
		#lmtemp1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1], "~", paste(colnames(phenoFile)[-c(1, 2, ncol(phenoFile)-1, ncol(phenoFile))], collapse="+"), "+", paste(colnames(GENOall)[indexes], collapse="*") )), data=dataForm)
		lmtemp1 = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1],  paste(design, paste(colnames(GENOall)[indexes],  collapse="*"), eQTL$SNP[j],sep="+"))), data=dataForm)

		### linear regression with adjustment
		### jackknife HC covariance HC3
		result = summary(lmtemp1)$coef
		ddtemp = vcovHC(lmtemp1, type="HC3")
		whichTerm = which(grepl(":", rownames(result)))
		statsReal = result[whichTerm,1]^2/ddtemp[whichTerm,whichTerm]
		pvalue4 = 1-pchisq(statsReal, df=1)
		eQTLresults$wald_sand_cond[j] = pvalue4
		eQTLresults$wald_cond[j] = result[whichTerm, 4]

		### permutation
		#nperm = 1000
		## null
		lmtempnull = lm(formula(paste0(colnames(subjInfo2)[ncol(subjInfo2)-1], paste(design, paste(colnames(GENOall)[indexes], collapse="+"), eQTL$SNP[j], sep="+") )), data=dataForm)

		if(grepl(":", rownames(result)[nrow(result)]))
		{	permSim1 = rep(NA, nperm)
			for(sim in 1:nperm)
			{       		if(sim%%100==0)
							{cat("sim", sim)
							}
							GENOtemp = GENO#[indexSim,]
							subjInfoTemp = cbind(matrix(rep(1, nrow(subjInfo2), 1)), subjInfo2, GENOtemp)
							colnames(subjInfoTemp)[1]="intercept"
							mutemp = as.matrix(subjInfoTemp[,c("intercept", names(lmtempnull$coef)[-1])]) %*% matrix(lmtempnull$coef, length(lmtempnull$coef), 1)
							subjInfoTemp$PHENOTYPE = rnorm(nrow(subjInfo), mutemp, sd=summary(lmtempnull)$sigma)
							lmtemp11 = lm(formula(paste0("PHENOTYPE", paste(design, paste(c(colnames(GENOall)[indexes], paste0(colnames(GENOall)[indexes], collapse="*")), collapse="+"), eQTL$SNP[j], sep="+") )), data=subjInfoTemp)

							resulttemp = summary(lmtemp11)$coef
							### jackknife HC covariance HC3
							ddtemp = vcovHC(lmtemp11, type="HC3")
							stats = (resulttemp[nrow(result),1])^2/ddtemp[nrow(resulttemp),nrow(resulttemp)]
							permSim1[sim] = stats
			}
			permPvalue1= sum(permSim1 >=abs(statsReal)|permSim1<=-abs(statsReal),na.rm=T)/sum(!is.na(permSim1))
			while(permPvalue1<= 0.00000001 & permPvalue1 >= 0.0000000001)
			{		        for(sim in 1:nperm)
							{       		if(sim%%100==0)
											{cat("sim", sim)
											}
											GENOtemp = GENO#[indexSim,]
											subjInfoTemp = cbind(matrix(rep(1, nrow(subjInfo2), 1)), subjInfo2, GENOtemp)
											colnames(subjInfoTemp)[1]="intercept"
											mutemp = as.matrix(subjInfoTemp[,c("intercept", names(lmtempnull$coef)[-1])]) %*% matrix(lmtempnull$coef, length(lmtempnull$coef), 1)
											subjInfoTemp$PHENOTYPE = rnorm(nrow(subjInfo), mutemp, sd=summary(lmtempnull)$sigma)
											lmtemp11 = lm(formula(paste0("PHENOTYPE", paste(design, paste(c(colnames(GENOall)[indexes], paste0(colnames(GENOall)[indexes], collapse="*")), collapse="+"), eQTL$SNP[j], sep="+") )), data=subjInfoTemp)

											resulttemp = summary(lmtemp11)$coef
											### jackknife HC covariance HC3
											ddtemp = vcovHC(lmtemp11, type="HC3")
											stats = (resulttemp[nrow(result),1])^2/ddtemp[nrow(resulttemp),nrow(resulttemp)]
											permSim1 = c(permSim1,stats)
							}
							permPvalue1= sum(permSim1 >=abs(statsReal)|permSim1<=-abs(statsReal),na.rm=T)/sum(!is.na(permSim1))
							cat("permPvalue1: ", permPvalue1, "\n")

			}
			eQTLresults$wald_sand_cond_perm[j] = permPvalue1
		}else
		{   eQTLresults$wald_sand_cond_perm[j] = NA
		}
		}
		sigResults$wald_cond[i] = max(eQTLresults$wald_cond, na.rm=T)
		sigResults$wald_sand_cond[i] =max(eQTLresults$wald_sand_cond, na.rm=T)
		sigResults$wald_sand_cond_perm[i] =max(eQTLresults$wald_sand_cond_perm, na.rm=T)
		sigResults$wald_sand_cond_perm_SNP[i] = eQTLresults$condSNP[which(eQTLresults$wald_sand_cond_perm==max(eQTLresults$wald_sand_cond_perm, na.rm=T))[1]]

 
	}           
	return (sigResults)

}
